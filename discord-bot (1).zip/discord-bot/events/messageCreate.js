const { addCoins } = require('../utils/db');

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot) return;
    if (!message.guild) return;
    addCoins(message.author.id, 1);
  },
};
