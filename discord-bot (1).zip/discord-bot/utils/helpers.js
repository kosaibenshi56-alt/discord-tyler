function isAdmin(member) {
  if (member.permissions.has('Administrator')) return true;
  return member.roles.cache.some(r => r.name.toLowerCase().includes('admin perm'));
}

function isOwnerOrCoOwner(member) {
  return member.roles.cache.some(r => {
    const name = r.name.toLowerCase();
    return name === 'owner' || name === 'co owner' || name === 'co-owner';
  });
}

function isVerified(member) {
  return member.roles.cache.some(r => r.name.toLowerCase() === 'verified');
}

function generateId() {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

module.exports = { isAdmin, isOwnerOrCoOwner, isVerified, generateId };
