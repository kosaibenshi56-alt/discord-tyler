const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRedeem, updateRedeem, getInventory } = require('../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('redeem')
    .setDescription('Redeem an item from your inventory')
    .addStringOption(o =>
      o.setName('id').setDescription('Redeem ID from your inventory').setRequired(true)
    )
    .addStringOption(o =>
      o.setName('roblox_username').setDescription('Your Roblox username').setRequired(true)
    )
    .addStringOption(o =>
      o.setName('gamepass_link').setDescription('Gamepass link').setRequired(true)
    ),

  async execute(interaction) {
    const redeemId = interaction.options.getString('id').toUpperCase();
    const robloxUsername = interaction.options.getString('roblox_username');
    const gampassLink = interaction.options.getString('gamepass_link');

    const redeem = getRedeem(redeemId);
    if (!redeem) {
      return interaction.reply({ content: '❌ Redeem ID not found.', ephemeral: true });
    }
    if (redeem.userId !== interaction.user.id) {
      return interaction.reply({ content: '❌ This redeem does not belong to you.', ephemeral: true });
    }
    if (redeem.status !== 'pending') {
      return interaction.reply({ content: `❌ This redeem has already been processed (status: **${redeem.status}**).`, ephemeral: true });
    }

    updateRedeem(redeemId, { robloxUsername, gampassLink, status: 'paid' });

    const embed = new EmbedBuilder()
      .setColor(0x00ff99)
      .setTitle('✅ Redeem Submitted!')
      .setDescription(
        `**Item:** ${redeem.itemName}\n**Redeem ID:** \`${redeemId}\`\n**Roblox Username:** ${robloxUsername}\n**Gamepass Link:** ${gampassLink}\n\nAn admin will process your redeem soon.`
      );
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
