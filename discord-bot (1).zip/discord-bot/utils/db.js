const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data.json');

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = { users: {}, redeems: {} };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function getUser(userId) {
  const db = loadDB();
  if (!db.users[userId]) {
    db.users[userId] = { coins: 0, inventory: [] };
    saveDB(db);
  }
  return db.users[userId];
}

function saveUser(userId, data) {
  const db = loadDB();
  db.users[userId] = data;
  saveDB(db);
}

function addCoins(userId, amount) {
  const user = getUser(userId);
  user.coins += amount;
  saveUser(userId, user);
  return user.coins;
}

function removeCoins(userId, amount) {
  const user = getUser(userId);
  user.coins = Math.max(0, user.coins - amount);
  saveUser(userId, user);
  return user.coins;
}

function getCoins(userId) {
  return getUser(userId).coins;
}

function addToInventory(userId, item) {
  const user = getUser(userId);
  user.inventory.push(item);
  saveUser(userId, user);
}

function getInventory(userId) {
  return getUser(userId).inventory;
}

function createRedeem(userId, itemId, itemName, redeemId) {
  const db = loadDB();
  db.redeems[redeemId] = {
    id: redeemId,
    userId,
    itemId,
    itemName,
    status: 'pending', // pending, paid, finished
    robloxUsername: null,
    gampassLink: null,
  };
  saveDB(db);
}

function getRedeem(redeemId) {
  const db = loadDB();
  return db.redeems[redeemId] || null;
}

function updateRedeem(redeemId, data) {
  const db = loadDB();
  if (!db.redeems[redeemId]) return false;
  db.redeems[redeemId] = { ...db.redeems[redeemId], ...data };
  saveDB(db);
  return true;
}

function getAllRedeems() {
  const db = loadDB();
  return db.redeems;
}

function removeFromInventory(userId, redeemId) {
  const user = getUser(userId);
  user.inventory = user.inventory.filter(i => i.redeemId !== redeemId);
  saveUser(userId, user);
}

module.exports = {
  getUser, saveUser, addCoins, removeCoins, getCoins,
  addToInventory, getInventory, createRedeem, getRedeem,
  updateRedeem, getAllRedeems, removeFromInventory,
};
