const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const SHOP_ITEMS = require('../utils/shopItems');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('View the coin shop'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x00bfff)
      .setTitle('🛒 Coin Shop')
      .setDescription('Use `/buy <id>` to purchase an item.')
      .addFields(
        SHOP_ITEMS.map(item => ({
          name: `[${item.id}] ${item.name}`,
          value: `**${item.cost.toLocaleString()} coins**`,
          inline: true,
        }))
      );
    await interaction.reply({ embeds: [embed] });
  },
};
