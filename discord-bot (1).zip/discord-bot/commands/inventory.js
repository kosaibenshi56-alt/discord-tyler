const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getInventory } = require('../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('View your inventory'),

  async execute(interaction) {
    const inv = getInventory(interaction.user.id);
    if (!inv.length) {
      return interaction.reply({ content: '🎒 Your inventory is empty.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x9b59b6)
      .setTitle('🎒 Your Inventory')
      .setDescription(inv.map(i => `• **${i.itemName}** — Redeem ID: \`${i.redeemId}\``).join('\n'));
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
