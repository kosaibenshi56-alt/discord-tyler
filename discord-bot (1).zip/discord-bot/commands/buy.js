const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getCoins, removeCoins, addToInventory, createRedeem } = require('../utils/db');
const { generateId } = require('../utils/helpers');
const SHOP_ITEMS = require('../utils/shopItems');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Buy an item from the shop')
    .addStringOption(o =>
      o.setName('id').setDescription('Item ID from /shop').setRequired(true)
    ),

  async execute(interaction) {
    const itemId = interaction.options.getString('id');
    const item = SHOP_ITEMS.find(i => i.id === itemId);
    if (!item) {
      return interaction.reply({ content: '❌ Invalid item ID. Use `/shop` to see items.', ephemeral: true });
    }

    const coins = getCoins(interaction.user.id);
    if (coins < item.cost) {
      return interaction.reply({
        content: `❌ You need **${item.cost.toLocaleString()} coins** but only have **${coins.toLocaleString()}**.`,
        ephemeral: true,
      });
    }

    const redeemId = generateId();
    removeCoins(interaction.user.id, item.cost);
    addToInventory(interaction.user.id, { itemId: item.id, itemName: item.name, redeemId });
    createRedeem(interaction.user.id, item.id, item.name, redeemId);

    const embed = new EmbedBuilder()
      .setColor(0x00ff99)
      .setTitle('✅ Purchase Successful!')
      .setDescription(`You bought **${item.name}**!\nRedeem ID: \`${redeemId}\`\nUse \`/redeem ${redeemId}\` to redeem it.`);
    await interaction.reply({ embeds: [embed] });
  },
};
