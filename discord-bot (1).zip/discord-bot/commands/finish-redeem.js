const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRedeem, updateRedeem, removeFromInventory } = require('../utils/db');
const { isAdmin } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('finish-redeem')
    .setDescription('[Admin] Mark a redeem as finished and notify the user')
    .addStringOption(o =>
      o.setName('id').setDescription('Redeem ID').setRequired(true)
    ),

  async execute(interaction, client) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ content: '❌ You need Admin permissions.', ephemeral: true });
    }

    const redeemId = interaction.options.getString('id').toUpperCase();
    const redeem = getRedeem(redeemId);

    if (!redeem) {
      return interaction.reply({ content: '❌ Redeem ID not found.', ephemeral: true });
    }
    if (redeem.status === 'finished') {
      return interaction.reply({ content: '❌ This redeem is already finished.', ephemeral: true });
    }

    updateRedeem(redeemId, { status: 'finished' });
    removeFromInventory(redeem.userId, redeemId);

    // DM the user
    try {
      const user = await client.users.fetch(redeem.userId);
      const dmEmbed = new EmbedBuilder()
        .setColor(0x00ff99)
        .setTitle('🎉 Your Redeem Has Been Processed!')
        .setDescription(
          `Your redeem for **${redeem.itemName}** has been completed!\n\n**Redeem ID:** \`${redeemId}\`\n**Roblox Username:** ${redeem.robloxUsername}\n\nThank you for your purchase!`
        );
      await user.send({ embeds: [dmEmbed] });
    } catch {
      // User may have DMs disabled
    }

    const embed = new EmbedBuilder()
      .setColor(0x00ff99)
      .setTitle('✅ Redeem Finished')
      .setDescription(`Redeem \`${redeemId}\` marked as finished. User has been notified.`);
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
