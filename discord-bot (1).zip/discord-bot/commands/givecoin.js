const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { addCoins, getCoins } = require('../utils/db');
const { isOwnerOrCoOwner } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('givecoin')
    .setDescription('[Owner/Co-Owner] Give coins to a user')
    .addUserOption(o => o.setName('user').setDescription('Target user').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true).setMinValue(1)),

  async execute(interaction) {
    if (!isOwnerOrCoOwner(interaction.member)) {
      return interaction.reply({ content: '❌ Only Owner or Co-Owner can use this command.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const newBalance = addCoins(target.id, amount);

    const embed = new EmbedBuilder()
      .setColor(0x00ff99)
      .setTitle('💸 Coins Given')
      .setDescription(`Gave **${amount.toLocaleString()} coins** to **${target.username}**.\nNew balance: **${newBalance.toLocaleString()} coins**`);
    await interaction.reply({ embeds: [embed] });
  },
};
