const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getCoins, addCoins, removeCoins } = require('../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Bet coins on a coinflip')
    .addIntegerOption(o =>
      o.setName('amount').setDescription('Amount of coins to bet').setRequired(true).setMinValue(1)
    )
    .addStringOption(o =>
      o.setName('side').setDescription('heads or tails').setRequired(true)
        .addChoices({ name: 'Heads', value: 'heads' }, { name: 'Tails', value: 'tails' })
    ),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const side = interaction.options.getString('side');
    const coins = getCoins(interaction.user.id);

    if (coins < amount) {
      return interaction.reply({
        content: `❌ You only have **${coins.toLocaleString()} coins**. You can't bet **${amount.toLocaleString()}**.`,
        ephemeral: true,
      });
    }

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const won = result === side;

    if (won) {
      addCoins(interaction.user.id, amount);
    } else {
      removeCoins(interaction.user.id, amount);
    }

    const newBalance = getCoins(interaction.user.id);
    const embed = new EmbedBuilder()
      .setColor(won ? 0x00ff99 : 0xff4444)
      .setTitle(won ? '🪙 You Won!' : '🪙 You Lost!')
      .setDescription(
        `The coin landed on **${result}**!\nYou chose **${side}** and ${won ? 'won' : 'lost'} **${amount.toLocaleString()} coins**.\nNew balance: **${newBalance.toLocaleString()} coins**`
      );
    await interaction.reply({ embeds: [embed] });
  },
};
