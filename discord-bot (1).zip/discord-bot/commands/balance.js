const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getCoins } = require('../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your coin balance')
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const coins = getCoins(target.id);
    const embed = new EmbedBuilder()
      .setColor(0xf5c518)
      .setTitle('💰 Coin Balance')
      .setDescription(`**${target.username}** has **${coins.toLocaleString()} coins**`);
    await interaction.reply({ embeds: [embed] });
  },
};
