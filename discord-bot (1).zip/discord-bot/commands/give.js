const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getCoins, removeCoins, addCoins } = require('../utils/db');
const { isVerified } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('give')
    .setDescription('Give coins to another user (requires Verified role)')
    .addUserOption(o => o.setName('user').setDescription('User to give coins to').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Amount of coins').setRequired(true).setMinValue(1)),

  async execute(interaction) {
    if (!isVerified(interaction.member)) {
      return interaction.reply({ content: '❌ You need the **Verified** role to give coins.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    if (target.id === interaction.user.id) {
      return interaction.reply({ content: '❌ You cannot give coins to yourself.', ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ content: '❌ You cannot give coins to a bot.', ephemeral: true });
    }

    const senderCoins = getCoins(interaction.user.id);
    if (senderCoins < amount) {
      return interaction.reply({
        content: `❌ You only have **${senderCoins.toLocaleString()} coins**.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, amount);
    addCoins(target.id, amount);

    const embed = new EmbedBuilder()
      .setColor(0x00bfff)
      .setTitle('💸 Coins Transferred')
      .setDescription(`**${interaction.user.username}** gave **${amount.toLocaleString()} coins** to **${target.username}**!`);
    await interaction.reply({ embeds: [embed] });
  },
};
