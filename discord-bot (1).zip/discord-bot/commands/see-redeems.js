const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getAllRedeems } = require('../utils/db');
const { isAdmin } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('see-redeems')
    .setDescription('[Admin] View all pending redeems'),

  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ content: '❌ You need Admin permissions.', ephemeral: true });
    }

    const all = getAllRedeems();
    const entries = Object.values(all).filter(r => r.status === 'paid');

    if (!entries.length) {
      return interaction.reply({ content: '📭 No pending redeems.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0xff9900)
      .setTitle('📋 Pending Redeems')
      .setDescription(
        entries.map(r =>
          `**ID:** \`${r.id}\`\n**User:** <@${r.userId}>\n**Item:** ${r.itemName}\n**Roblox:** ${r.robloxUsername}\n**Gamepass:** ${r.gampassLink}\n**Status:** ${r.status}\n──────────`
        ).join('\n')
      );
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
