const SHOP_ITEMS = [
  { id: '1', name: '125m Brainrot', cost: 1500, description: '125m Brainrot' },
  { id: '2', name: '150m Brainrot', cost: 2000, description: '150m Brainrot' },
  { id: '3', name: '175m Brainrot', cost: 2500, description: '175m Brainrot' },
  { id: '4', name: '200m Brainrot', cost: 3000, description: '200m Brainrot' },
  { id: '5', name: '100m Garama', cost: 5000, description: '100m Garama' },
];

module.exports = SHOP_ITEMS;
